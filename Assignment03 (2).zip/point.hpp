#ifndef POINT_HPP
#define POINT_HPP

class Point {
public:
    Point(double xCoord, double yCoord) : x(xCoord), y(yCoord) {}
    Point() : x(0), y(0) {} // Default constructor

    double getX() const { return x; }
    double getY() const { return y; }

private:
    double x;
    double y;
};

#endif
