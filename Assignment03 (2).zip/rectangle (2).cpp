#include "Rectangle.hpp"
#include <cmath>
#include <iostream>

Rectangle::Rectangle(Point pt1, Point pt2, Point pt3, Point pt4) {
    if (!setCoord(pt1, pt2, pt3, pt4)) {
        std::cout << "Error: The points do not form a rectangle." << std::endl;
    }
}

bool Rectangle::setCoord(Point pt1, Point pt2, Point pt3, Point pt4) {
    p1 = pt1;
    p2 = pt2;
    p3 = pt3;
    p4 = pt4;
    if (!isValid(p1) || !isValid(p2) || !isValid(p3) || !isValid(p4)) {
        return false;
    }
    return isRectangle(p1, p2, p3, p4);
}

bool Rectangle::isValid(const Point& pt) const {
    return (pt.getX() >= 0 && pt.getX() <= 20 && pt.getY() >= 0 && pt.getY() <= 20);
}

bool Rectangle::isRectangle(const Point& pt1, const Point& pt2, const Point& pt3, const Point& pt4) const {
    double d1 = sqrt(pow(pt1.getX() - pt2.getX(), 2) + pow(pt1.getY() - pt2.getY(), 2));
    double d2 = sqrt(pow(pt3.getX() - pt4.getX(), 2) + pow(pt3.getY() - pt4.getY(), 2));
    double d3 = sqrt(pow(pt2.getX() - pt3.getX(), 2) + pow(pt2.getY() - pt3.getY(), 2));
    double d4 = sqrt(pow(pt4.getX() - pt1.getX(), 2) + pow(pt4.getY() - pt1.getY(), 2));

    return (d1 == d2 && d3 == d4);
}

double Rectangle::length() const {
    double d1 = sqrt(pow(p1.getX() - p2.getX(), 2) + pow(p1.getY() - p2.getY(), 2));
    double d2 = sqrt(pow(p1.getX() - p4.getX(), 2) + pow(p1.getY() - p4.getY(), 2));
    return std::max(d1, d2);
}

double Rectangle::width() const {
    double d1 = sqrt(pow(p1.getX() - p2.getX(), 2) + pow(p1.getY() - p2.getY(), 2));
    double d2 = sqrt(pow(p1.getX() - p4.getX(), 2) + pow(p1.getY() - p4.getY(), 2));
    return std::min(d1, d2);
}

double Rectangle::perimeter() const {
    return 2 * (length() + width());
}

double Rectangle::area() const {
    return length() * width();
}

bool Rectangle::square() const {
    return (length() == width());
}
