#ifndef RECTANGLE_HPP
#define RECTANGLE_HPP

#include "Point.hpp"

class Rectangle {
public:
    Rectangle(Point pt1, Point pt2, Point pt3, Point pt4);
    bool setCoord(Point pt1, Point pt2, Point pt3, Point pt4);
    double length() const;
    double width() const;
    double perimeter() const;
    double area() const;
    bool square() const;

private:
    Point p1, p2, p3, p4;

    bool isValid(const Point& pt) const;
    bool isRectangle(const Point& pt1, const Point& pt2, const Point& pt3, const Point& pt4) const;
};

#endif
